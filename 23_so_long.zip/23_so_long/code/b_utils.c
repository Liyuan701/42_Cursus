/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   b_utils.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/16 15:11:37 by lifan             #+#    #+#             */
/*   Updated: 2024/11/10 14:53:12 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

// count in the whole map, there are how many c.
int	ft_count(char **map, char c)
{
	int	y;
	int	x;
	int	count;

	y = 0;
	count = 0;
	while (map[y])
	{
		x = 0;
		while (map[y][x])
		{
			if (map[y][x] == c)
				count++;
			x++;
		}
		y++;
	}
	return (count);
}

// for the given map, find the coordonate of the given C
void	ft_locate(char c, t_game *game)
{
	int		i;
	int		j;

	i = 0;
	while (game->map[i] != NULL)
	{
		j = 0;
		while (game->map[i][j] != '\0')
		{
			if (game->map[i][j] == c)
			{
				game->pos.x = j;
				game->pos.y = i;
			}
			j++;
		}
		i++;
	}
}

// Just to combine the errors and free
void	ft_error_and_free(int code, t_game *game)
{
	ft_error(code);
	ft_free_game(game);
}

int	ft_strlen_long(const char *str, t_game *game)
{
	int	i;
	int	count;

	if (!str)
		return (ft_error_and_free(E_NO, game), FAIL);
	i = 0;
	count = 0;
	while (str[i])
	{
		if (!(str[i] <= 13 && str[i] >= 9))
			count++;
		i++;
	}
	return (count);
}

int	ft_find(char *str, char c)
{
	int		i;
	int		find;

	i = 0;
	find = 0;
	while (str[i])
	{
		if (str[i] == c)
			find = 1;
		i++;
	}
	return (find);
}
