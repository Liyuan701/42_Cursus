/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/28 00:13:33 by lifan             #+#    #+#             */
/*   Updated: 2024/07/28 00:13:33 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//* In this page we will deal with all map opening/malloc/and the testmap
#include "../include/so_long.h"

//Here I get the new line by gxl, and use strdup to copy it.
//I also got the nb of rows and nb of letters per row.
int	ft_get_map(t_game *game, char *filename)
{
	int		fd;
	int		y;
	char	*nxl_tmp;

	y = 0;
	ft_init_map(game, filename);
	fd = open(filename, O_RDONLY);
	if (fd == -1)
		return (ft_error_and_free(E_NOMAP, game), FAIL);
	while (1)
	{
		nxl_tmp = get_next_line(fd);
		if (!nxl_tmp)
			break ;
		game->map[y] = ft_strdup(nxl_tmp);
		if (!game->map[y])
			return (ft_error_and_free(E_MEM, game), FAIL);
		game->state = MAP;
		free(nxl_tmp);
		y++;
	}
	close(fd);
	ft_get_map_s(game, y);
	return (0);
}

int	ft_get_map_s(t_game *game, int y)
{
	game->map[y] = NULL;
	if (!game->map)
		return (ft_error_and_free(E_MEM, game), FAIL);
	if (y == 0 || !game->map[y - 1])
		return (ft_error_and_free(E_MEM, game), FAIL);
	game->width = ft_strlen_long(game->map[y - 1], game);
	return (0);
}

int	ft_init_map(t_game *game, char *filename)
{
	int		fd;
	int		row;
	char	*nxl_map;

	row = 0;
	fd = open(filename, O_RDONLY);
	if (fd == -1)
		return (ft_error_and_free(E_NOMAP, game), FAIL);
	while (1)
	{
		nxl_map = get_next_line(fd);
		if (!nxl_map)
			break ;
		free(nxl_map);
		row++;
	}
	close(fd);
	game->height = row;
	game->map = (char **)malloc((row + 1) * sizeof(char *));
	if (!game->map)
		return (ft_error_and_free(E_MEM, game), FAIL);
	return (0);
}

//To know whether my game has a solution, I will copy the map to do the test
void	ft_copy_map(t_game *game)
{
	int		y;

	y = 0;
	game->tmap = (char **)malloc(sizeof(char *) * (game->height + 1));
	if (!game->tmap)
		ft_error_and_free(E_MEM, game);
	while (y < game->height)
	{
		game->tmap[y] = ft_strdup(game->map[y]);
		if (!game->tmap[y])
			ft_error_and_free(E_MEM, game);
		y++;
	}
	game->tmap[y] = NULL;
}

// From the initial P place, fill all O,C,E by P.
// Here I also got the first game->pos.
// Quit fill_map when there is no recursive to do.
void	ft_fill_map(int x, int y, t_game *game)
{
	if (x < 0 || x >= game->width || y < 0 || y >= game->height)
		return ;
	game->tmap[y][x] = CAT;
	if (y + 1 >= 0 && (game->tmap[y + 1][x] == GRASS || game->tmap[y + 1][x] \
			== VASE || game->tmap[y + 1][x] == EXIT))
		ft_fill_map(x, y + 1, game);
	if (x + 1 >= 0 && (game->tmap[y][x + 1] == GRASS || game->tmap[y][x + 1] \
			== VASE || game->tmap[y][x + 1] == EXIT))
		ft_fill_map(x + 1, y, game);
	if (y - 1 >= 0 && (game->tmap[y - 1][x] == GRASS || game->tmap[y - 1][x] \
		== VASE || game->tmap[y - 1][x] == EXIT))
		ft_fill_map(x, y - 1, game);
	if (x - 1 >= 0 && (game->tmap[y][x - 1] == GRASS || game->tmap[y][x - 1] \
		== VASE || game->tmap[y][x - 1] == EXIT))
		ft_fill_map(x - 1, y, game);
}
