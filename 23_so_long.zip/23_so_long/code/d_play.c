/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   d_play.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/20 12:55:10 by lifan             #+#    #+#             */
/*   Updated: 2024/11/09 13:28:13 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//*In this page we will deal with all objets init/move
#include "../include/so_long.h"

void	ft_play(t_game *game)
{
	mlx_hook(game->win_ptr, 17, 1L << 17, ft_free_game, game);
	mlx_hook(game->win_ptr, 2, 1L << 0, ft_key_press, game);
	mlx_loop_hook(game->mlx_ptr, &ft_render_map, game);
}

// somethinf is wrong here, that when I FIRST D, I went down.
// Define key_presse movements
int	ft_key_press(int keycode, t_game *game)
{
	if (keycode == D || keycode == RIGHT)
		ft_see(game, +1, 0);
	else if (keycode == A || keycode == LEFT)
		ft_see(game, -1, 0);
	else if (keycode == W || keycode == UP)
		ft_see(game, 0, -1);
	else if (keycode == S || keycode == DOWN)
		ft_see(game, 0, +1);
	else if (keycode == Q || keycode == ESC)
	{
		ft_printf("---------------------------------\n");
		ft_printf("|   You won't help me?           |\n");
		ft_printf("|  T T See you next time, meow ~ |\n");
		ft_printf("---------------------------------\n");
		ft_free_game(game);
	}
	return (0);
}

// Got the move sign, and to do the walk/collect/exit,depends on what we meet.
int	ft_see(t_game *game, int mx, int my)
{
	int	nx;
	int	ny;
	int	obj;

	nx = game->pos.x + mx;
	ny = game->pos.y + my;
	obj = game->map[ny][nx];
	if (obj == VASE || obj == GRASS)
	{
		game->move++;
		game->map[game->pos.y][game->pos.x] = GRASS;
		game->pos.y = ny;
		game->pos.x = nx;
		game->map[ny][nx] = CAT;
		ft_printf("You have moved %d steps.\n", game->move);
		if (obj == VASE)
		{
			game->collect--;
			ft_printf("you still have %d vases to find!\n", game->collect);
		}
	}
	else if (obj == EXIT)
		ft_announce(game);
	return (0);
}

void	ft_announce(t_game *game)
{
	if (game->collect == 0)
	{
		game->map[game->pos.y][game->pos.x] = GRASS;
		game->move++;
		ft_printf("---------------------------------\n");
		ft_printf("|Congratulations Meow!          |\n");
		ft_printf("|After %d moves,                |\n", game->move);
		ft_printf("|you have found all vases!      |\n");
		ft_printf("---------------------------------\n");
		ft_free_game(game);
	}
	if (game->collect != 0)
		ft_printf("Help me to find all vases before leaving please!\n");
}
