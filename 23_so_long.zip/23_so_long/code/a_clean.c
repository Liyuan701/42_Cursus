/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   clean.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 21:27:54 by lifan             #+#    #+#             */
/*   Updated: 2024/07/27 21:27:54 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

// free map line by line
void	ft_free_map(t_game *game)
{
	int	y;

	if (game->map == NULL)
		return ;
	y = 0;
	while (game->map[y] != NULL)
	{
		free(game->map[y]);
		y++;
	}
	free(game->map);
	game->map = NULL;
	if (game->tmap != NULL)
		ft_free_tmap(game);
}

void	ft_free_tmap(t_game *game)
{
	int	y;

	if (game->tmap == NULL)
		return ;
	y = 0;
	while (game->tmap[y] != NULL)
	{
		free(game->tmap[y]);
		y++;
	}
	free(game->tmap);
	game->tmap = NULL;
}

void	ft_free_img(t_game *game)
{
	if (game->mlx_ptr)
	{
		if (game->img.i_cat)
			mlx_destroy_image(game->mlx_ptr, game->img.i_cat);
		if (game->img.i_exit)
			mlx_destroy_image(game->mlx_ptr, game->img.i_exit);
		if (game->img.i_wall)
			mlx_destroy_image(game->mlx_ptr, game->img.i_wall);
		if (game->img.i_vase)
			mlx_destroy_image(game->mlx_ptr, game->img.i_vase);
		if (game->img.i_grass)
			mlx_destroy_image(game->mlx_ptr, game->img.i_grass);
		ft_memset(&(game->img), 0, sizeof(t_img));
	}
}

// Accordinf to different states, free elements
int	ft_free_game(t_game *game)
{
	if (game->state == CHECK || game->state == MAP)
		ft_free_map(game);
	else if (game->state == RENDER)
	{
		ft_free_map(game);
		ft_free_img(game);
		if (game->mlx_ptr)
			mlx_destroy_display(game->mlx_ptr);
		free(game->mlx_ptr);
	}
	else if (game->state == PLAY)
	{
		ft_free_map(game);
		ft_free_img(game);
		mlx_destroy_window(game->mlx_ptr, game->win_ptr);
		if (game->mlx_ptr)
			mlx_destroy_display(game-> mlx_ptr);
		free(game->mlx_ptr);
	}
	exit(0);
}
