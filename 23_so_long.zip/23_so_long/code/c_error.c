/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 21:27:45 by lifan             #+#    #+#             */
/*   Updated: 2024/07/27 21:27:45 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//* In this page, we will deal with distribute check tasks and error messages
#include "../include/so_long.h"

int	ft_check_map(t_game *game, char *filename)
{
	if (ft_check_name(filename) == FAIL)
		return (ft_error_and_free(E_NOBER, game), FAIL);
	ft_get_map(game, filename);
	if (!game->map)
		return (ft_error_and_free(E_MEM, game), FAIL);
	game->state = CHECK;
	if (ft_check_rec(game) == FAIL)
		return (ft_error_and_free(E_REC, game), FAIL);
	if (ft_check_close(game) == FAIL)
		return (ft_error_and_free(E_WALL, game), FAIL);
	if (ft_check_onlyc(game) == FAIL)
		return (ft_error_and_free(E_CHAR, game), FAIL);
	if (ft_count(game->map, CAT) != 1)
		return (ft_error_and_free(E_CAT, game), FAIL);
	if (ft_count(game->map, EXIT) != 1)
		return (ft_error_and_free(E_EXIT, game), FAIL);
	game->collect = ft_count(game->map, VASE);
	if (game->collect < 1)
		return (ft_error_and_free(E_VASE, game), FAIL);
	if (ft_check_solve(game) == FAIL)
		return (ft_error_and_free(E_WAY, game), FAIL);
	game->state = MAP;
	return (0);
}

void	ft_error(int code)
{
	ft_printf("Error!\n");
	if (code == E_NOA)
		ft_printf("One argument is needed.\n");
	else if (code == E_NOMAP)
		ft_printf("Can't open the map.\n");
	else if (code == E_NOIMG)
		ft_printf("Can't open one of the imgs.\n");
	else if (code == E_NOBER)
		ft_printf("The file should be in .ber format.\n");
	else if (code == E_WAY)
		ft_printf("There is no way to go in this map.\n");
	else if (code == E_MEM)
		ft_printf("Allocation failed.\n");
	else if (code == E_REC)
		ft_printf("Map should be rectangular.\n");
	else if (code == E_WALL)
		ft_printf("Map should be surrounded by walls.\n");
	else if (code == E_BIG)
		ft_printf("Don't be greedy, your map is too big.\n");
	ft_error_s(code);
}

void	ft_error_s(int code)
{
	if (code == E_CHAR)
		ft_printf("Map cotains invalides chars.\n");
	else if (code == E_CAT)
		ft_printf("Too few/many cats.\n");
	else if (code == E_EXIT)
		ft_printf("Too few/many exits.\n");
	else if (code == E_VASE)
		ft_printf("There is no vase to collect.\n");
	else if (code == E_MLX)
		ft_printf("Something is wrong with the MLX.\n");
	else if (code == E_NO)
		ft_printf("Something is wrong, but I don't know where.\n");
}
