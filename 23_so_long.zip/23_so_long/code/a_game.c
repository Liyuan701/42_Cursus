/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   a_game.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/24 17:07:35 by lifan             #+#    #+#             */
/*   Updated: 2024/11/10 15:13:34 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

void	ft_initial(t_game *game)
{
	ft_memset(game, 0, sizeof(t_game));
	ft_memset(&(game->img), 0, sizeof(t_img));
	game->pos.x = -1;
	game->pos.y = -1;
}

int	main(int ac, char **av)
{
	t_game	game;

	ft_initial(&game);
	if (ac != 2)
		return (ft_error_and_free(E_NOA, &game), FAIL);
	ft_check_map(&game, av[1]);
	game.state = RENDER;
	game.mlx_ptr = mlx_init();
	if (!game.mlx_ptr)
		return (ft_error_and_free(E_MLX, &game), FAIL);
	ft_load_img(&game);
	game.state = PLAY;
	game.win_ptr = mlx_new_window(game.mlx_ptr, \
		game.width * 40, game.height * 60, "So long");
	if (!game.win_ptr)
		return (ft_error_and_free(E_MLX, &game), FAIL);
	ft_play(&game);
	mlx_loop(game.mlx_ptr);
	return (ft_error_and_free(E_NO, &game), FAIL);
}
