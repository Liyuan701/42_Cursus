/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   c_check.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/16 12:20:17 by lifan             #+#    #+#             */
/*   Updated: 2024/11/10 14:23:28 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/so_long.h"

//get the last 4 letters and compare to the .ber
int	ft_check_name(char *name)
{
	size_t	len;

	len = ft_strlen(name);
	if (len <= 4)
		return (FAIL);
	if (ft_strncmp(name + len - 4, ".ber", 4) != 0)
		return (FAIL);
	return (0);
}

//make sure the four walls are all composed of 1
int	ft_check_close(t_game *game)
{
	int	y;
	int	x;
	int	width;
	int	height;

	y = 0;
	x = 0;
	width = game->width;
	height = game->height;
	if (width == 0 || height == 0)
		return (FAIL);
	while (y < game->height)
	{
		if (game->map[y][0] != WALL || game->map[y][width - 1] != WALL)
			return (FAIL);
		y ++;
	}
	while (x < width)
	{
		if (game->map[0][x] != WALL || game->map[height - 1][x] != WALL)
			return (FAIL);
		x ++;
	}
	return (0);
}

// make sure that every line have the same nb of col.
int	ft_check_rec(t_game *game)
{
	int	y;

	y = 0;
	while (y < game->height)
	{
		if (ft_strlen_long(game->map[y], game) != game->width)
			return (FAIL);
		y++;
	}
	return (0);
}

// Make sure every letter in the map is one of the 5 letters.
int	ft_check_onlyc(t_game *game)
{
	int		y;
	int		x;
	char	c;

	y = 0;
	while (y < game->height)
	{
		x = 0;
		while (x < game->width)
		{
			c = game->map[y][x];
			if (ft_find("01CPE", c) == 0)
				return (FAIL);
			x++;
		}
		y++;
	}
	return (0);
}

// Make sure that the CAT has access to all VASE and EXIT.
int	ft_check_solve(t_game *game)
{
	ft_copy_map(game);
	ft_locate(CAT, game);
	if (game->pos.x != -1 && game->pos.y != -1)
		ft_fill_map(game->pos.x, game->pos.y, game);
	if (ft_count(game->tmap, VASE) != 0 || ft_count(game->tmap, EXIT) != 0)
	{
		ft_error_and_free(E_WAY, game);
	}
	ft_free_tmap(game);
	return (0);
}
