/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   d_render.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/09/20 13:46:54 by lifan             #+#    #+#             */
/*   Updated: 2024/10/30 00:45:16 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//* In this page we will deal with all rendering things, map and objets
#include "../include/so_long.h"

void	ft_load_img(t_game *game)
{
	ft_get_img(game, &game->img.i_cat, P_CAT);
	ft_get_img(game, &game->img.i_exit, P_EXIT);
	ft_get_img(game, &game->img.i_vase, P_VASE);
	ft_get_img(game, &game->img.i_wall, P_WALL);
	ft_get_img(game, &game->img.i_grass, P_GRASS);
}

int	ft_get_img(t_game *game, void **img, char *path)
{
	int	width;
	int	height;

	*img = mlx_xpm_file_to_image(game->mlx_ptr, path, &width, &height);
	if (*img == NULL)
		return (ft_error_and_free(E_NOIMG, game), FAIL);
	return (0);
}

//Iterate the map and render all the map on the screen
int	ft_render_map(t_game *game)
{
	int	y;
	int	x;

	y = 0;
	while (game->map[y])
	{
		x = 0;
		while (game->map[y][x])
		{
			if (game->map[y][x] == CAT)
				ft_draw(game, game->img.i_cat, x, y);
			else if (game->map[y][x] == VASE)
				ft_draw(game, game->img.i_vase, x, y);
			else if (game->map[y][x] == WALL)
				ft_draw(game, game->img.i_wall, x, y);
			else if (game->map[y][x] == EXIT)
				ft_draw(game, game->img.i_exit, x, y);
			else if (game->map[y][x] == GRASS)
				ft_draw(game, game->img.i_grass, x, y);
			x++;
		}
		y++;
	}
	return (0);
}

void	ft_draw(t_game *game, void *img, int x, int y)
{
	mlx_put_image_to_window(game->mlx_ptr, game->win_ptr, \
		img, x * IMG_W, y * IMG_H);
}
