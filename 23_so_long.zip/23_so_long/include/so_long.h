/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lifan <rohanafan@sina.com>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/27 18:02:51 by lifan             #+#    #+#             */
/*   Updated: 2024/10/27 18:02:51 by lifan            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

//Headers
# include <stdio.h>
# include <unistd.h>
# include <fcntl.h>
# include <stdlib.h>
# include <string.h>
# include <errno.h>
# include "../mlx_linux/mlx.h"
# include "../libft/libft.h"

//Keys
# define WALL			'1'
# define GRASS 			'0'
# define VASE  			'C'
# define CAT			'P'
# define EXIT 		 	'E'
# define W				119
# define A				97
# define S				115
# define D				100
# define Q				113
# define R				114
# define LEFT  			65361
# define RIGHT 			65363
# define UP  			65362
# define DOWN  			65364
# define ESC  			65307

// STATE
# define INIT			0
# define CHECK			1
# define MAP			2
# define RENDER			3
# define PLAY			4
# define FAIL			1

// Names
# define P_WALL		"./img/wall.xpm"
# define P_GRASS	"./img/grass.xpm"
# define P_VASE		"./img/vase.xpm"
# define P_CAT		"./img/cat.xpm"
# define P_EXIT		"./img/exit.xpm"

# define IMG_H		60
# define IMG_W		40

# define E_NOA		101
# define E_NOBER	102
# define E_WAY		103
# define E_NOMAP	104
# define E_MEM		105
# define E_REC		106
# define E_WALL		107
# define E_CHAR		108
# define E_NUM		109
# define E_CAT		110
# define E_EXIT		111
# define E_VASE		112
# define E_MLX		113
# define E_NO		114
# define E_NOIMG	115
# define E_BIG		116

//structures

typedef struct pos
{
	int	x;
	int	y;
}	t_pos;

typedef struct s_img
{
	void	*i_grass;
	void	*i_cat;
	void	*i_vase;
	void	*i_wall;
	void	*i_exit;
}	t_img;

typedef struct s_game
{
	void		*mlx_ptr;
	void		*win_ptr;
	char		**map;
	char		**tmap;
	int			height;
	int			width;
	int			state;
	int			move;
	int			collect;
	t_img		img;
	t_pos		pos;
}	t_game;

//Functions
void	ft_free_map(t_game *game);
void	ft_free_tmap(t_game *game);
void	ft_free_img(t_game *game);
int		ft_free_game(t_game *game);
int		ft_get_map(t_game *game, char *filename);
int		ft_init_map(t_game *game, char *filename);
void	ft_copy_map(t_game *game);
void	ft_fill_map(int x, int y, t_game *game);
void	ft_fill_map_s(int x, int y, t_game *game);
int		ft_count(char **map, char c);
void	ft_locate(char c, t_game *game);
int		ft_check_name(char *name);
int		ft_check_close(t_game *game);
int		ft_check_rec(t_game *game);
int		ft_check_onlyc(t_game *game);
int		ft_check_solve(t_game *game);
int		ft_check_map(t_game *game, char *filename);
void	ft_error(int code);
void	ft_play(t_game *game);
int		ft_key_press(int keycode, t_game *game);
int		ft_see(t_game *game, int mx, int my);
void	ft_announce(t_game *game);
void	ft_load_img(t_game *game);
int		ft_get_img(t_game *game, void **img, char *path);
int		ft_render_map(t_game *game);
void	ft_draw(t_game *game, void *img, int x, int y);
void	ft_error_s(int code);
void	ft_error_and_free(int code, t_game *game);
int		ft_strlen_long(const char *str, t_game *game);
int		ft_find(char *str, char c);
int		ft_get_map_s(t_game *game, int y);

#endif
